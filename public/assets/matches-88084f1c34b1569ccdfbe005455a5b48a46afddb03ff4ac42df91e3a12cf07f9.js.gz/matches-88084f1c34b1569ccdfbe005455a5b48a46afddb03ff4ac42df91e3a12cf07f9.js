$(document).ready(function() {
	$('#nav-result').addClass('selected');
});
