$(document).ready(function() {
    $('#myCarousel').carousel({interval: 5000});
});
