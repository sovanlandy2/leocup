$(document).ready(function() {
	$('#nav-news').addClass('selected');
});
