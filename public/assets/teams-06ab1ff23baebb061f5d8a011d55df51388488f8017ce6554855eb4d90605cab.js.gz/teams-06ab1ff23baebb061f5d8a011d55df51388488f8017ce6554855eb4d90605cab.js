$(document).ready(function() {
	$('#nav-team').addClass('selected');
});
